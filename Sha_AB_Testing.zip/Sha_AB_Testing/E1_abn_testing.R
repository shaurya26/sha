#Group_A
#----------------------A/B Testing----------------------#
setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp1.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)

exp.data$control_target = as.factor(exp.data$control_target)
exp.data[,1] = NULL
summary(exp.data)
target = exp.data$control_target
exp.data = exp.data[,-3]
df_M <- data.frame("Names" = character(0),"P_Values" = integer(0),"Mean_of_grpA" = integer(0),"Mean_of_grpB" = integer(0),"Mean_of_grpC" = integer(0),"Mean_of_grpD" = integer(0),stringsAsFactors = FALSE)

##---------------For_Loop--------------------##
#The Wilcoxon signed-rank test is used when comparing two related samples, matched samples, or repeated measurements on a single sample to assess whether their population mean ranks differ
#In wilcoxon test Data are paired and come from the same population.
#Each pair is chosen randomly and independently.
for (i in 2:(ncol(exp.data))){
  exp.name = names(exp.data[i])
  exp.class = class(exp.data[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    a = kruskal.test(exp.data[,i] ~ target)$p.value
    Mean_A = mean(exp.data[target == 'control',i])
    Mean_B = mean(exp.data[target == 'Hidden',i])
    Mean_C = mean(exp.data[target == 'hide leaderboards',i])
    Mean_D = mean(exp.data[target == 'original',i])
    Mean_A[is.na(Mean_A)] <- 0
    Mean_B[is.na(Mean_B)] <- 0
    Mean_C[is.na(Mean_C)] <- 0
    Mean_D[is.na(Mean_D)] <- 0
    df_M[nrow(df_M)+1,] <- c(exp.name,a,Mean_A,Mean_B,Mean_C,Mean_D)
  }
}

#-------------Calculating % diff between mean--------------------

df_M$Mean_of_grpA = as.numeric(df_M$Mean_of_grpA)
df_M$Mean_of_grpB = as.numeric(df_M$Mean_of_grpB)
df_M$Mean_of_grpC = as.numeric(df_M$Mean_of_grpC)
df_M$Mean_of_grpD = as.numeric(df_M$Mean_of_grpD)
mean_table <- cbind(df_M$Mean_of_grpA,df_M$Mean_of_grpB,df_M$Mean_of_grpC,df_M$Mean_of_grpD)
colnames(mean_table) <- c("Mean_of_grpA","Mean_of_grpB","Mean_of_grpC","Mean_of_grpD")
mean_table[is.na(mean_table)] <- 0
mean_table <- as.data.frame(mean_table)
Perc_diff_Means <- abs(mean_table$Mean_of_grpA - mean_table$Mean_of_grpB)*100
Perc_diff_Means1 <- abs(mean_table$Mean_of_grpC - mean_table$Mean_of_grpD)*100
mean_table <- cbind(mean_table,Perc_diff_Means,Perc_diff_Means1)
df_M <- cbind(df_M,Perc_diff_Means,Perc_diff_Means1)

#-----------saving both grpA and grpB in one data_frame--------------------------
write.csv(df_M,"df_M.csv")

#-------------------------------------------------------------------